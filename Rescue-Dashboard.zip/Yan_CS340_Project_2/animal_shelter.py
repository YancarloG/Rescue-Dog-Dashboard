from pymongo import MongoClient

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password, host, port, db, collection):
        # Initialize the MongoClient to access MongoDB databases and collections
        self.client = MongoClient(f'mongodb://{username}:{password}@{host}:{port}')
        self.database = self.client[db]
        self.collection = self.database[collection]

    # Method to implement the C in CRUD (Create)
    def create(self, data):
        try:
            if data:
                self.collection.insert_one(data)
                return True
            else:
                raise ValueError("Data is empty. Cannot insert.")
        except Exception as e:
            print(f"An error occurred while inserting data: {e}")
            return False

    # Method to implement the R in CRUD (Read)
    def read(self, query):
        try:
            result = list(self.collection.find(query))
            if result:
                return result
            else:
                print("No documents found.")
                return []
        except Exception as e:
            print(f"An error occurred while reading data: {e}")
            return []

    # Method to implement the U in CRUD (Update)
    def update(self, query, new_values):
        try:
            if query and new_values:
                result = self.collection.update_many(query, {"$set": new_values})
                return result.modified_count
            else:
                raise ValueError("Query or new values are missing.")
        except Exception as e:
            print(f"An error occurred while updating data: {e}")
            return 0

    # Method to implement the D in CRUD (Delete)
    def delete(self, query):
        try:
            if query:
                result = self.collection.delete_many(query)
                return result.deleted_count
            else:
                raise ValueError("Query is empty. Cannot delete.")
        except Exception as e:
            print(f"An error occurred while deleting data: {e}")
            return 0
